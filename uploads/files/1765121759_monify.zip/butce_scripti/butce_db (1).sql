-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Anamakine: 127.0.0.1
-- Üretim Zamanı: 06 Ara 2025, 20:38:47
-- Sunucu sürümü: 10.4.32-MariaDB
-- PHP Sürümü: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `butce_db`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `abonelikler`
--

CREATE TABLE `abonelikler` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `baslik` varchar(100) NOT NULL,
  `miktar` decimal(10,2) NOT NULL,
  `tur` enum('gelir','gider') NOT NULL,
  `kategori` varchar(50) NOT NULL,
  `baslangic_tarihi` date NOT NULL,
  `sonraki_tarih` date NOT NULL,
  `periyot` enum('gunluk','haftalik','aylik','yillik') NOT NULL DEFAULT 'aylik'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `butce_hedefleri`
--

CREATE TABLE `butce_hedefleri` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `kategori` varchar(50) NOT NULL,
  `hedef_tutar` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Tablo döküm verisi `butce_hedefleri`
--

INSERT INTO `butce_hedefleri` (`id`, `user_id`, `kategori`, `hedef_tutar`) VALUES
(3, 1, 'Market & Gıda', 1000.00);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `hesaplar`
--

CREATE TABLE `hesaplar` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `hesap_adi` varchar(100) NOT NULL,
  `tur` enum('nakit','banka','kredi_karti','altin_doviz') NOT NULL DEFAULT 'nakit',
  `guncel_bakiye` decimal(15,2) NOT NULL DEFAULT 0.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Tablo döküm verisi `hesaplar`
--

INSERT INTO `hesaplar` (`id`, `user_id`, `hesap_adi`, `tur`, `guncel_bakiye`) VALUES
(2, 1, 'Ziraat Bankası', 'banka', 130.00),
(3, 1, 'Bonus Kart', 'kredi_karti', 0.00),
(4, 1, 'garanti', 'banka', 303.00);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `islemler`
--

CREATE TABLE `islemler` (
  `id` int(11) NOT NULL,
  `aciklama` varchar(255) NOT NULL,
  `miktar` decimal(10,2) NOT NULL,
  `tur` enum('gelir','gider') NOT NULL,
  `kategori` varchar(50) DEFAULT NULL,
  `tarih` timestamp NOT NULL DEFAULT current_timestamp(),
  `user_id` int(11) NOT NULL,
  `hesap_id` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Tablo döküm verisi `islemler`
--

INSERT INTO `islemler` (`id`, `aciklama`, `miktar`, `tur`, `kategori`, `tarih`, `user_id`, `hesap_id`) VALUES
(1, 'deneme', 111.00, 'gelir', NULL, '2025-11-25 11:38:00', 0, 1),
(2, 'deneme', 2.00, 'gider', NULL, '2025-11-25 11:38:04', 0, 1),
(3, 'sa', 11.00, 'gider', NULL, '2025-11-25 11:47:46', 0, 1),
(4, 'Migros', 150.00, 'gider', 'Market & Gıda', '2025-11-25 12:00:27', 1, 1),
(5, 'kira geliri', 12000.00, 'gelir', 'Diğer Gelir', '2025-11-25 12:03:52', 1, 1),
(7, 'İade', 500.00, 'gelir', 'Ek İş', '2025-12-06 13:39:31', 1, 1),
(10, 'Freelance', 1000.00, 'gelir', 'Ek İş', '2025-12-05 21:00:00', 1, 1),
(18, 'sa', 100.00, 'gider', 'Market & Gıda', '2025-12-06 17:10:46', 1, 0);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `kategoriler`
--

CREATE TABLE `kategoriler` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `ad` varchar(50) NOT NULL,
  `tur` enum('gelir','gider') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Tablo döküm verisi `kategoriler`
--

INSERT INTO `kategoriler` (`id`, `user_id`, `ad`, `tur`) VALUES
(1, 1, 'Market & Gıda', 'gider'),
(2, 1, 'Fatura & Kira', 'gider'),
(3, 1, 'Ulaşım', 'gider'),
(4, 1, 'Maaş', 'gelir'),
(5, 1, 'Ek İş', 'gelir'),
(7, 1, 'Freelance', 'gelir');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `kullanicilar`
--

CREATE TABLE `kullanicilar` (
  `id` int(11) NOT NULL,
  `ad_soyad` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `sifre` varchar(255) NOT NULL,
  `kayit_tarihi` timestamp NOT NULL DEFAULT current_timestamp(),
  `pin_kodu` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Tablo döküm verisi `kullanicilar`
--

INSERT INTO `kullanicilar` (`id`, `ad_soyad`, `email`, `sifre`, `kayit_tarihi`, `pin_kodu`) VALUES
(1, 'burak', 'admin@admin.com', '$2y$10$JUlHlamxVRd3iS6IW8oLWevULkcrVzbGnn0svVahSs08P6PgTJ5My', '2025-11-25 11:52:17', '$2y$10$mELtKDymwNVkiT.DJh5SYOL7CzyT/8fLp99Ns/VKhtXi7AJ9G9JNu');

--
-- Dökümü yapılmış tablolar için indeksler
--

--
-- Tablo için indeksler `abonelikler`
--
ALTER TABLE `abonelikler`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `butce_hedefleri`
--
ALTER TABLE `butce_hedefleri`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `hesaplar`
--
ALTER TABLE `hesaplar`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `islemler`
--
ALTER TABLE `islemler`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `kategoriler`
--
ALTER TABLE `kategoriler`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `kullanicilar`
--
ALTER TABLE `kullanicilar`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Dökümü yapılmış tablolar için AUTO_INCREMENT değeri
--

--
-- Tablo için AUTO_INCREMENT değeri `abonelikler`
--
ALTER TABLE `abonelikler`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Tablo için AUTO_INCREMENT değeri `butce_hedefleri`
--
ALTER TABLE `butce_hedefleri`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Tablo için AUTO_INCREMENT değeri `hesaplar`
--
ALTER TABLE `hesaplar`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Tablo için AUTO_INCREMENT değeri `islemler`
--
ALTER TABLE `islemler`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- Tablo için AUTO_INCREMENT değeri `kategoriler`
--
ALTER TABLE `kategoriler`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- Tablo için AUTO_INCREMENT değeri `kullanicilar`
--
ALTER TABLE `kullanicilar`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
