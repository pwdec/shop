<?php
session_start(); // BU SATIRI EKLEMEK ZORUNDASIN!

$host = 'localhost';
$dbname = 'butce_db';
$username = 'root';
$password = '';

try {
    $db = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Veritabanı hatası: " . $e->getMessage());
}

// Otomasyonu başlat
include_once 'kontrol.php';
?>